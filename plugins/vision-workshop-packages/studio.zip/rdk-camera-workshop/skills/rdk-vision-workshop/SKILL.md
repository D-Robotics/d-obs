---
name: rdk-vision-workshop
description: 在 Studio 按 180 分钟方案带学员完成 X5 + IMX415 点亮、Gamma 调优、RoboGO 异步训练、A/B/C 分流、实时检测和个人成果打包。
version: 0.7.4
trigger: 开始 Workshop, 开始Workshop, 继续 Workshop, 继续Workshop, 打开课堂工作台, 视觉 Workshop,视觉 Pipeline,相机与 BPU 工作坊,继续视觉任务,相机训练部署全流程,采集基线图,三张基线图,展示基线图,查看 Gamma 对照图,展示 Gamma 实拍
risk: medium
requires_board: false
permissions: network
category: device
enabled: true
---

# 视觉 Pipeline · 180 分钟 Workshop

本课程依据 [飞书方案](https://horizonrobotics.feishu.cn/docx/UdhhdVXYXoPLgfxmZ32cJBSAnRb)。课程执行方法见 [操作稿](references/course-runbook.md)，实机交接见 [检测交接](references/tuning-handoff.md)。

1. 用户要开始或继续时先调用 `mcp__rdk-vision-workshop__vision_course_view({})` 取得原工位，并调用 `studio_open_url({url,target:'local'})` 请求打开。宿主没有网页工具时给出可点击的原工位链接。然后调用 `vision_course_camera_status` 读取工位绑定及最近预检，再使用 `vision_course_next` 推进当前一步。已知课堂开始时间时传实际经过的 `elapsedMinutes`，明确彩排时标注模拟时间。查看总课表用 `vision_course_plan`。
2. 工作台打开后，用 `vision_course_sync` 的空参数读取当前记录。完成实际工具操作后，用 `{patch:{evidence:{...}}}` 把本轮实际回执引用同步到工作台；确实解决的阻塞放入 `clearBlockers`。根据宿主对本地记录更新的权限执行。每轮只给学员当前一步，说明完成条件和证据。宿主有可用且已授权的工具时，从相机、GPU 或板端工具执行当前一步。实际工具缺失时指出哪项配置或操作需要用户或助教处理。不要把课程工具的规划回执当成执行回执。
3. 相机工具返回实际实验 ID 后，把 `camera:{experimentId}` 写入 `vision_course_sync` 的 `patch`。有实际相机 AI Run 后同步 `{camera:{experimentId,runId}}`。提示学员在工作台核对这轮新帧、实际回读和采集时间，再附入成果包。
4. 开场第 35–45 分钟采三种基线，第 45–50 分钟按组提交 RoboGO。收到已有 Run ID 后只查询原 Run。茶歇由助教核对，第 110 分钟个人盲选，第 120 分钟助教预检，第 130 分钟按实际产物与设备状态做 A/B/C 选择。
5. A 使用本人训练和量化产物。B 记录预置模型来源，完成本人板端操作。C 只归档已观看的演示记录。切换路径保留原 Run 和实际来源。板端模型需核对三类输出与实际 SHA-256。检测流须读取实际生效的 ISP 配置和本轮新帧。
6. 操作相机前保存原始配置。ISP 未恢复时按相机插件的恢复状态继续处理。交付时保存个人手册、tuning、媒体、实际模型来源、待完成项及终态恢复记录，并打开 ZIP 核对。传给用户的文件从真实制品取，未完成的路径保留说明。

确认相机可用时先读 `vision_course_camera_status` 的 `cameraBinding` 和 `latestPreflight`，工位关联以实际实验记录为准。需要实时检查时按宿主审批调用 `vision_course_preflight({run:true})`，随后通过 `vision_course_camera_status` 查询进度。分别报告服务、板卡和两帧推进的回执。工位未关联时打开关联入口，相机未开流时在原实验点亮，历史条数上限回执可在服务更新后重查原实验；`vision_device_archive_capacity` 时核对实际归档空间，保留旧回执。预检通过后才报告本轮实时画面。

用户只要看图时，从 `vision_course_isp_status`（Gamma）或 `vision_course_camera_status`（照片、基线）拿原工位链接，按 `presentation.archivedFrames` 说明本轮已归档项和缺项，在工作台逐张下载。无需生成脚本或运行设备操作。请求打开和实际加载按各自回执报告。自制图片和 HTML 分别用宿主 `studio_open_local_preview({path: 成品路径, openSystemApp:false})` 交付，仅在工具可用时调用。核对 `__type:'studio_local_preview'`、`ok:true`、文件名、字节数以及图片的 `imageUrl` 或 HTML 的 `fileUrl`；有对应回执才报告入口已提供。

课堂 Gamma 使用工位 ISP 工具。先 `vision_course_isp` 的 `save` 保存原始版本，再按已确认的学员观察目标执行 `gamma`。使用 `vision_course_isp_status` 查看实际应用、回读和前后图；学员记录保留或恢复理由。先 `revert` 取得恢复后新图，再用 `reload` 验证同一个候选。最后按课堂授权调用 `restore` 恢复并停流。候选不符合单模块要求时按失败回执说明缺项；恢复结果不明确时继续核对同一个原始快照。

拍照和基线图先读取 `vision_course_camera_status`。`baselineRequested:false` 只表示未发起三图。用户说「看基线图」「这几张展示给我看」时，打开工具返回的工作台链接，展示当前工位已归档的图，保持只读。用户明确要拍照时，用 `vision_course_camera` 的 `photo`。采三图用 `baseline`，传学员确认的固定场景；场景变更用 `retake`。需要实验绑定时先打开工作台关联本工位。操作后查询原状态，确定哪一项成功，再展示带原件下载的入口。工具不可用时指出缺失工具和工作台入口，通过 Studio 插件载入技能；不得用终端、SSH、读取凭据或绑定插件安装目录绕过本轮权限。只读排查禁止调用烧录、写设备或修改 ISP 的工具。
